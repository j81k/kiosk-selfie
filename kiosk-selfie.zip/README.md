# kiosk-selfie

Repo: https://github.com/j81k/kiosk-selfie.git


Email:
----------------------------------------------------------------

[Template]
	* Template found at "</templates/email/template-0.php>"

	* Default Template: template-0.php

	* Params: 
		01. {templateImg}	# Created template Image (Edit template file to set where you want to display!)
		02. {name} 			# Automatically extracted from email to Address
		







[Important]
----------------------------------------------------------------

[Ubuntu]
* Kill Chrome fully
	> killall -q chrome

* Start Chrome
	> google-chrome --kiosk --kiosk-printing --unsafely-treat-insecure-origin-as-secure="http://atkoscales.com/kiosk/" --disable-web-security --user-data-dir http://atkoscales.com/kiosk/	

