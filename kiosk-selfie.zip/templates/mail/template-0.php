<h1>Hello {name},</h1>
<p>Many more happy returns of the day!!</p>
<div>{templateImg}</div>