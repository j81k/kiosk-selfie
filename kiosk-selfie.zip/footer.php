<?php

/*
 * File Name    : footer.php
 * Created On   : 2017-05-28 22:55
 */

?>

        </section> <!-- /content -->
        <footer>
            
            
        </footer>
    </body>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/script.js"></script>
</html>
    
 

